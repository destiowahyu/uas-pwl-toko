# Toko Online CI v1.0

Aplikasi toko online berbasis web menggunakan framework CodeIgniter 3

**NOTE:** File database ada di assets/db/ci_shop.sql

## Tampilan Homepage

<p align="center">
  <img src="https://i.ibb.co/44TqPrJ/Annotation-2020-04-26-063829.png" alt="SS">
</p>

## Login

|      User     |       Email      	|    Password   |
|:-------------:|:-----------------:|:-------------:|
| Administrator | admin@admin.com  	| admin@cishop	|
| Member        | member@member.com	| member@cishop	|
